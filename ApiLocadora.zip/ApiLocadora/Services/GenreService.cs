﻿using ApiLocadora.DataContexts;
using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.EntityFrameworkCore;

namespace ApiLocadora.Services
{
    public class GenreService
    {
        private readonly AppDbContext _context;

        public GenreService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ICollection<Genre>> GetAll()
        {
            var list = await _context.genres.ToListAsync();
            return list;
        }

        public async Task<Genre> GetOneById(int id)
        {
            try
            {
                return await _context.genres.SingleOrDefaultAsync(x => x.Id == id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<Genre> Create(GenreDto item)
        {
            try
            {
                var newGenre = new Genre(
                item.Nome
                 );

                await _context.genres.AddAsync(newGenre);
                await _context.SaveChangesAsync();

                return newGenre;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<Genre> Update(int id, GenreDto item)
        {
            try
            {

                // Encontrar o filme com o ID especificado
                var genre = _context.genres.FirstOrDefault(x => x.Id == id);

                // Atualizar as propriedades do genero
                genre.Nome = item.Nome;
             

                // Salvar as mudanças no banco de dados

                await _context.SaveChangesAsync();

                // Retornar 200 OK com o filme atualizado
                return genre;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<Genre> Delete(int id)
        {
            try
            {
                var listGenres = await _context.genres.ToListAsync();
                for (int i = 0; i < listGenres.Count; i++)
                {
                    if (listGenres[i].Id + 1 == id)
                    {
                        listGenres.RemoveAt(i);
                        _context.genres.Remove(listGenres[i]);
                        await _context.SaveChangesAsync();
                        return listGenres[i];
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }

}

