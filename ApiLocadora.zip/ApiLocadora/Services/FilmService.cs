﻿using ApiLocadora.DataContexts;
using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Update.Internal;
using System.Data;

namespace ApiLocadora.Services
{
    public class FilmService
    {
        private readonly AppDbContext _context;

        public FilmService(AppDbContext context)
        {
            _context = context;
        }

        public async Task< ICollection<Film> > GetAll()
        {
            var list = await _context.films.ToListAsync();
            return list;
        }

        public async Task <Film> GetOneById(int id)
        {
            try
            {
                return await _context.films.SingleOrDefaultAsync(x=>x.Id==id);
            } 
            catch (Exception ex)
            {
                throw new Exception (ex.Message);
            }
        }

        public async Task <Film> Create(FilmDto item)
        {
            try
            {
             var newFilm = new Film(
             item.Nome, item.Data_lancamento, item.Diretor,
             item.Descricao, item.Avaliacao
              );

                await _context.films.AddAsync(newFilm);
                await _context.SaveChangesAsync();

                return newFilm;
            } 
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task <Film> Update(int id, FilmDto item)
        {
            try
            {

                // Encontrar o filme com o ID especificado
                var film = _context.films.FirstOrDefault(x => x.Id == id);

                // Atualizar as propriedades do filme
                film.Nome = item.Nome;
                film.Data_lancamento = item.Data_lancamento;
                film.Diretor = item.Diretor;
                // Descomentar as linhas abaixo se precisar atualizar essas propriedades
                // film.Genre = item.Genre;
                // film.Studio = item.Studio;
                film.Descricao = item.Descricao;

                // Salvar as mudanças no banco de dados
                await _context.SaveChangesAsync();

                // Retornar 200 OK com o filme atualizado
                return film;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task <Film> Delete(int id)
        {
         try 
            {
                var listFilms = await _context.films.ToListAsync();
                for (int i = 0; i < listFilms.Count; i++)
                {
                    if (listFilms[i].Id + 1 == id)
                    {
                        listFilms.RemoveAt(i);
                        _context.films.Remove(listFilms[i]);
                        await _context.SaveChangesAsync();
                        return listFilms[i];
                    }
                }
                return null;
            } 
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private async Task<bool> Exist(int id)
        {
            return await _context.films.AnyAsync(x => x.Id == id);
        }



    } 
}
