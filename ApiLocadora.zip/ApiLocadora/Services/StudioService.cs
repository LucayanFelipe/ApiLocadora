﻿namespace ApiLocadora.Services
{
    public class StudioService
    {
    }
}
