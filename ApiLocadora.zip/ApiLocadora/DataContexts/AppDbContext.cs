﻿using Microsoft.EntityFrameworkCore;
using ApiLocadora.Models;

namespace ApiLocadora.DataContexts
{
    public class AppDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public DbSet<Film> films {  get; set; }

        public DbSet<Genre> genres { get; set; }

        public DbSet<Studio> studios { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) 
        {
            
        }
    }
}
