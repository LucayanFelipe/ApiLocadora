﻿using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.AspNetCore.Mvc;
using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using ApiLocadora.DbContext;
using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;



namespace ApiLocadora.Controllers
{
    [Route("/Studio")]
    [ApiController]
    public class StudioController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StudioController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public async Task<IActionResult> Search()
        {
            var listStudio = await _context.studios.ToListAsync();
            return Ok(listStudio);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> SearchId(int id)
        {
            var listStudios = await _context.studios.ToListAsync();

            for (int i = 0; i < listStudios.Count; i++)
            {
                if (listStudios[i].Id == id)
                {
                    var searchedStudio = new Studio(listStudios[i].Nome, listStudios[i].Distribuidor);
                    List<Studio> listSearchedStudio = new List<Studio>();
                    listSearchedStudio.Add(searchedStudio);
                    return Ok(listSearchedStudio);
                }
            }
            return NotFound();
        }


        [HttpPost("")]
        public async Task<IActionResult> Create([FromBody] StudioDto item)
        {
            var newStudio = new Studio(
            item.Nome, item.Distribuidor);

            await _context.studios.AddAsync(newStudio);
            await _context.SaveChangesAsync();

            return Created("", newStudio);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] StudioDto item)
        {
            // Encontrar o filme com o ID especificado
            var studio = _context.studios.FirstOrDefault(f => f.Id == id);

            // Se o filme não for encontrado, retornar 404
            if (studio == null)
            {
                return NotFound();
            }

            // Atualizar as propriedades do filme
            studio.Nome = item.Nome;
            studio.Distribuidor = item.Distribuidor;

            await _context.SaveChangesAsync();

            // Retornar 200 OK com o filme atualizado
            return Ok(studio);
        }

        [HttpDelete("{id}")]

        public async Task<IActionResult> Delete(int id)
        {
            var listStudios = await _context.studios.ToListAsync();

            for (int i = 0; i < listStudios.Count; i++)
            {
                if (listStudios[i].Id + 1 == id)
                {
                    listStudios.RemoveAt(i);
                    _context.studios.Remove(listStudios[i]);
                    await _context.SaveChangesAsync();
                    return Ok(listStudios);
                }
            }
            return NotFound();
        }
    }
}
