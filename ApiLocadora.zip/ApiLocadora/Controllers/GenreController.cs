﻿using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using ApiLocadora.DbContext;
using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;


namespace ApiLocadora.Controllers
{
    [Route("/Genre")]
    [ApiController]
    public class GenreController : ControllerBase
    {
        private readonly AppDbContext _context;

        public GenreController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public async Task <IActionResult> Search()
        {
            var listGenres = await _context.genres.ToListAsync();
            return Ok(listGenres);
        }


        [HttpGet("{id}")]
        public async Task <IActionResult> SearchId(int id)
        {
            var listGenres = await _context.genres.ToListAsync();

            for (int i = 0; i < listGenres.Count; i++)
            {
                if (listGenres[i].Id == id)
                {
                    var searchedGenre = new Genre(listGenres[i].Nome);
                    List<Genre> listSearchedGenre = new List<Genre>();
                    listSearchedGenre.Add(searchedGenre);
                    return Ok(listSearchedGenre);
                }
            }
            return NotFound();
        }



        [HttpPost("")]
        public async Task <IActionResult> Create([FromBody] GenreDto item)
        {
            var newGenre = new Genre(
            item.Nome);

            await _context.genres.AddAsync(newGenre);
            await _context.SaveChangesAsync();

            return Created("", newGenre);
        }

        [HttpPut("{id}")]
        public async Task <IActionResult> Update(int id, [FromBody] GenreDto item)
        {
            // Encontrar o filme com o ID especificado
            var genre = _context.genres.FirstOrDefault(f => f.Id == id);

            // Se o filme não for encontrado, retornar 404
            if (genre == null)
            {
                return NotFound();
            }

            // Atualizar as propriedades do filme
            genre.Nome = item.Nome;

            await _context.SaveChangesAsync();

            // Retornar 200 OK com o filme atualizado
            return Ok(genre);
        }

      

        [HttpDelete("{id}")]

        public async Task <IActionResult> Delete(int id)
        {
            var listGenres = await _context.genres.ToListAsync();

            for (int i = 0; i < listGenres.Count; i++)
            {
                if (listGenres[i].Id + 1 == id)
                {
                    listGenres.RemoveAt(i);
                    _context.genres.Remove(listGenres[i]);
                    await _context.SaveChangesAsync();
                    return Ok(listGenres);
                }
            }
            return NotFound();
        }

    }
}
