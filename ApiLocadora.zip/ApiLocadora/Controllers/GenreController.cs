﻿using ApiLocadora.Dtos;
using ApiLocadora.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;

using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;
using ApiLocadora.Services;


namespace ApiLocadora.Controllers
{
    [Route("/Genre")]
    [ApiController]
    public class GenreController : ControllerBase
    {
    
        private readonly GenreService _service;

        public GenreController(GenreService service)
        {
            _service = service;
        }

        //GET ALL
        [HttpGet("")]
        public async Task<IActionResult> Search()
        {
            var listGenres = await _service.GetAll();

            return Ok(listGenres);
        }


        //GET ONE BY ID
        [HttpGet("{id}")]
        public async Task<IActionResult> SearchId(int id)
        {

            try
            {
                var listGenres = await _service.GetOneById(id);
                if (listGenres == null) return NotFound("Informação não encontrada");
                return Ok(listGenres);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }


        //CREATE
        [HttpPost("")]
        public async Task<IActionResult> Create([FromBody] GenreDto item)
        {
            try
            {
                var listGenres = await _service.Create(item);

                if (listGenres == null) return NotFound("Informação não encontrada");
                return Ok(listGenres);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }


        //UPDATE
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] GenreDto item)
        {

            try
            {
                var listGenres = await _service.Update(id, item);
                if (listGenres == null) return NotFound("Informação não encontrada");
                return Ok(listGenres);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }


        }

        //DELETE
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var listGenres = await _service.Delete(id);
                if (listGenres == null) return NotFound("Informação não encontrada");
                return Ok(listGenres);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }

    }
}
