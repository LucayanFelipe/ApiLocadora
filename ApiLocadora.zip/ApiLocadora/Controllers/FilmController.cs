﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApiLocadora.Models;
using ApiLocadora.Dtos;
using ApiLocadora.DbContext;
using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;

namespace ApiLocadora.Controllers
{
    [Route("/")]
    [ApiController]
    public class FilmController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FilmController(AppDbContext context)
        {
            _context = context;
        }
        

        [HttpGet("films")]
        public async Task<IActionResult> Search()
        {
            var listFilms = await _context.films.ToListAsync();
            return Ok(listFilms);
        }


//BUSCAR POR ID
        [HttpGet("films/{id}")]
        public async Task<IActionResult> SearchId(int id)
        {
            var listFilms = await _context.films.ToListAsync();
            for (int i = 0; i < listFilms.Count; i++)
            {
                if (listFilms[i].Id == id)
                {
                    var searchedFilm = new Film(
              listFilms[i].Nome, listFilms[i].Data_lancamento, listFilms[i].Diretor,
             listFilms[i].Descricao, listFilms[i].Avaliacao
              );
                    List<Film> listSearchedFilm = new List<Film>();
                   listSearchedFilm.Add(searchedFilm);
                   return Ok(listSearchedFilm);
                }
            }
            return NotFound();
        }


        //CADASTRAR
        [HttpPost("films")]
        public async Task <IActionResult> Create([FromBody] FilmDto item)
        {    
            var newFilm = new Film(
               item.Nome, item.Data_lancamento, item.Diretor,
               item.Descricao, item.Avaliacao
                );

            await _context.films.AddAsync(newFilm);
            await _context.SaveChangesAsync();
            
            return Created("", newFilm);
               
            /*
            var newStudio = new Studio(item.Studio.Name, item.Studio.Distributor);
            DbContextApi.Studios.Add(newStudio);

            var newGenre = new Genre(item.Genre.Name);
            DbContextApi.Genres.Add(newGenre);

            DbContextApi.Films.Add(newFilm);
            */
       
        }
        

        //atualizar
        [HttpPut("films/{id}")]
        public async Task  <IActionResult> Update(int id, [FromBody] FilmDto item)
        {
            // Encontrar o filme com o ID especificado
            var film = _context.films.FirstOrDefault(f => f.Id == id);

            // Se o filme não for encontrado, retornar 404
            if (film == null)
            {
                return NotFound();
            }

            // Atualizar as propriedades do filme
            film.Nome = item.Nome;
            film.Data_lancamento = item.Data_lancamento;
            film.Diretor = item.Diretor;
            // Descomentar as linhas abaixo se precisar atualizar essas propriedades
            // film.Genre = item.Genre;
            // film.Studio = item.Studio;
            film.Descricao = item.Descricao;

            // Salvar as mudanças no banco de dados
            await _context.SaveChangesAsync();

            // Retornar 200 OK com o filme atualizado
            return Ok(film);
        }

        [HttpDelete("films/{id}")]

        public async Task<IActionResult> Delete(int id)
        {
            var listFilms = await _context.films.ToListAsync();

            for (int i=0; i< listFilms.Count;i++)
            {
                if (listFilms[i].Id+1 == id)
                {
                    listFilms.RemoveAt(i);
                    _context.films.Remove(listFilms[i]);
                    await _context.SaveChangesAsync();
                    return Ok(listFilms);
                }
            }
            return NotFound();
        }


    }
}
