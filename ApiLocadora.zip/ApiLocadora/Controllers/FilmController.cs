﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApiLocadora.Models;
using ApiLocadora.Dtos;

using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;
using ApiLocadora.Services;

namespace ApiLocadora.Controllers
{
    [Route("/")]
    [ApiController]
    public class FilmController : ControllerBase
    {
  
        private readonly FilmService _service;

        public FilmController(FilmService service)
        {
            _service = service;
        }

        //GET ALL
        [HttpGet("films")]
        public async Task<IActionResult> Search()
        {
            var listFilms = await _service.GetAll();
            
            return Ok(listFilms);
        }


        //GET ONE BY ID
        [HttpGet("films/{id}")]
        public async Task<IActionResult> SearchId(int id)
        {

            try 
            {
            var listFilms = await _service.GetOneById(id);
                if (listFilms == null) return NotFound("Informação não encontrada");
            return Ok(listFilms);
            } 
            catch (Exception ex) 
            {
                return Problem(ex.Message);
            }
        }


        //CREATE
        [HttpPost("films")]
        public async Task<IActionResult> Create( [FromBody] FilmDto item )
        {
            try
            {
            var listFilms = await _service.Create(item);

                if (listFilms == null) return NotFound("Informação não encontrada");
                return Ok(listFilms);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }


        //UPDATE
        [HttpPut("films/{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] FilmDto item)
        {

            try
            {
                var listFilms = await _service.Update(id, item);
                if (listFilms == null) return NotFound("Informação não encontrada");
                return Ok(listFilms);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }

           
        }

        //DELETE
        [HttpDelete("films/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var listFilms = await _service.Delete(id);
                if (listFilms == null) return NotFound("Informação não encontrada");
                return Ok(listFilms);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }


    }
}
