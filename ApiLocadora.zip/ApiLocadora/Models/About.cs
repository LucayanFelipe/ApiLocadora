﻿namespace ApiLocadora.Models
{
    public class About
    {
        public int Id { get; set; } 
        public string Details { get; set; }
    }
}
