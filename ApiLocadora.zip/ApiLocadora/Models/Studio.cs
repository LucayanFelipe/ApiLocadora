﻿namespace ApiLocadora.Models
{
    public class Studio
    {
        public int Id { get; set; } 

        public string Nome { get; set; }
        public string Distribuidor { get; set; }

        public Studio(string name, string distributor)
        {
            Nome = name;
            Distribuidor = distributor;
        }
        public Studio() { }
    }
}
