﻿using System.ComponentModel.DataAnnotations;

namespace ApiLocadora.Dtos
{
    public class GenreDto
    {
      
        [Required]
        public required string Nome { get; set; }
    }
}
