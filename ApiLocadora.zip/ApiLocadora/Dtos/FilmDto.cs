﻿using ApiLocadora.Models;
using System.ComponentModel.DataAnnotations;

namespace ApiLocadora.Dtos
{
    public class FilmDto
    {

        [Required]
        public required string Nome { get; set; }
        [Required]
        public required DateTime? Data_lancamento { get; set; }
        [Required]
        public required string Diretor { get; set; }
        [Required]
   //     public required Genre Genre { get; set; }
    //    [Required]
    //    public required Studio Studio { get; set; }
    //    [Required]
        public required string Descricao { get; set; }
        [Required]
        public required double Avaliacao { get; set; }



    }
}
