﻿namespace ApiLocadora.Models
{
    public class About
    {
        public Guid Id { get; set; } = new Guid();
        public string Details { get; set; }
    }
}
