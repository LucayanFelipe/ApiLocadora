﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ApiLocadora.Models;
using ApiLocadora.Dtos;
using ApiLocadora.DbContext;
using ApiLocadora.DataContexts;
using Microsoft.EntityFrameworkCore;

namespace ApiLocadora.Controllers
{
    [Route("/")]
    [ApiController]
    public class FilmController : ControllerBase
    {
        private readonly AppDbContext _context;

        public FilmController(AppDbContext context)
        {
            _context = context;
        }
        

        [HttpGet("films")]
        public async Task<IActionResult> Search()
        {
            var listFilms = await _context.films.ToListAsync();
            return Ok(listFilms);
        }


        /*BUSCAR POR ID
        [HttpGet("films/{id}")]
        public IActionResult SearchId(Guid id)
        {
            for (int i = 0; i < DbContextApi.Films.Count; i++)
            {
                if (DbContextApi.Films[i].Id == id)
                {
                    var searchedFilm = new Film(
              DbContextApi.Films[i].Name, DbContextApi.Films[i].ReleaseDate, DbContextApi.Films[i].Director,
             DbContextApi.Films[i].Description
              );
                    List<Film> listSearchedFilm = new List<Film>();
                   listSearchedFilm.Add(searchedFilm);
                   return Ok(listSearchedFilm);
                }
            }
            return NotFound();
        }*/


        //CADASTRAR
        [HttpPost("films")]
        public async Task <IActionResult> Create([FromBody] FilmDto item)
        {    
            var newFilm = new Film(
               item.Name, item.ReleaseDate, item.Director,
               item.Description, item.AvaliationIMDB
                );

            await _context.films.AddAsync(newFilm);
            await _context.SaveChangesAsync();
            
            return Created("", newFilm);
               
            /*
            var newStudio = new Studio(item.Studio.Name, item.Studio.Distributor);
            DbContextApi.Studios.Add(newStudio);

            var newGenre = new Genre(item.Genre.Name);
            DbContextApi.Genres.Add(newGenre);

            DbContextApi.Films.Add(newFilm);
            */
       
        }
        

        //atualizar
        [HttpPut("films/{id}")]
        public async Task  <IActionResult> Update(int id, [FromBody] FilmDto item)
        {
            bool updated = false;

            // Encontrar o filme com o ID especificado
            var film = _context.films.FirstOrDefault(f => f.Id == id);

            // Se o filme não for encontrado, retornar 404
            if (film == null)
            {
                return NotFound();
            }

            // Atualizar as propriedades do filme
            film.Nome = item.Name;
            film.Data_lancamento = item.ReleaseDate;
            film.Diretor = item.Director;
            // Descomentar as linhas abaixo se precisar atualizar essas propriedades
            // film.Genre = item.Genre;
            // film.Studio = item.Studio;
            film.Descricao = item.Description;

            // Salvar as mudanças no banco de dados
            await _context.SaveChangesAsync();

            // Retornar 200 OK com o filme atualizado
            return Ok(film);
        }

        [HttpDelete("films/{id}")]

        public IActionResult Delete(int id, [FromBody] FilmDto item)
        {
            var newFilm = new Film(
                  item.Name, item.ReleaseDate, item.Director,
               item.Description, item.AvaliationIMDB
                );
            
            for (int i=0; i< DbContextApi.Films.Count;i++)
            {
                if (DbContextApi.Films[i].Id == id)
                {
                    DbContextApi.Films.RemoveAt(i);
                    return Ok(DbContextApi.Films);
                }
            }
            return NotFound();
        }


    }
}
